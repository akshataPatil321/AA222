using Plots
using LinearAlgebra
include("helpers.jl")
include("simple.jl")

# Simple 1:
function simple1_init()
    return rand(2) * 2.0
end
# Function:
function simple1(x,y)
    return -x * y + 2.0 / (3.0 * sqrt(3.0))
end
# Gradient:
function simple1_gradient(x::Vector)
    return [-x[2], -x[1]]
end
# Constraints:
function simple1_constraints(x::Vector)
    return [x[1] + x[2]^2 - 1,
            -x[1] - x[2]]
end
# Constraint 1:
function simple1_constraints1(x1, x2)
    return x1 + x2^2 - 1
end
# Constraint 2:
function simple1_constraints2(x1, x2)
    return -x1 - x2
end

# Simple 2:
function simple2_init()
    return rand(2) .* 2.0 .- 1.0
end
# Function:
function simple2(x,y)
    return (1.0 - x)^2 + 100.0 * (y - x^2)^2
end
# Gradient:
function simple2_gradient(x::Vector)
    storage = zeros(2)
    storage[1] = -2.0 * (1.0 - x[1]) - 400.0 * (x[2] - x[1]^2) * x[1]
    storage[2] = 200.0 * (x[2] - x[1]^2)
    return storage
end
# Constraints:
function simple2_constraints(x::Vector)
    return [(x[1]-1)^3 - x[2] + 1,
            x[1] + x[2] - 2]
end
# Constraint 1:
function simple2_constraints1(x1,x2)
    return (x1-1)^3 - x2 + 1
end
# Constraint 2:
function simple2_constraints2(x1,x2)
    return x1 + x2 - 2
end


# Simple 3:
function simple3_init()
    b = 2.0 .* [1.0, -1.0, 0.0]
    a = -2.0 .* [1.0, -1.0, 0.0]
    return rand(3) .* (b-a) + a
end
# function:
function simple3(x, y, z)
    return x - 2*y + z + sqrt(6.0)
end

function simple3_gradient(x::Vector)
    return [1, -2, 1]
end

function simple3_constraints(x::Vector)
    return [x[1]^2 + x[2]^2 + x[3]^2 - 1]
end
# Quadratic Penalty Optimization Method:
function penalty_method(f, g, c, x0, n, α, γ, rho, gamma)
    x_H = [x0]
    f_H = [f(x0)]
    # α = 18.5
    while count(f, g, c) < n-15
        # Quadratic Penalty:
        mod_f(x) = f(x) + rho * sum(max.(0,c(x)).^2)
        x_new, α = hook_jeeves(mod_f, x_H[end], α,  γ)
        # μ = x_H[end]
        # Σ = diagm(x_H[end])
        # P = MvNormal(μ, Σ)
        # x_new = cross_entropy_method(mod_f, g, c, n, P, 100, 10, 100)
        rho *= gamma
        if c(x_new) == 0
            push!(x_H, x_new)
            push!(f_H, f(x_new))
            break
        end
        push!(x_H, x_new)
        push!(f_H, f(x_new))
    end
    return x_H, f_H 
end

# Unconstrained Optimization using Hook Jeeves:
basis(i, n) = [k == i ? 1.0 : 0.0 for k in 1 : n]
function hook_jeeves(f, x, α, γ)
y, n = f(x), length(x)
improved = false
x_best, y_best = x, y
for i in 1:n
    for sgn in (-1, 1)
        x′ = x + sgn*α*basis(i, n)
        y′ = f(x′)
        if y′ < y_best
            x_best, y_best, improved = x′, y′, true
        end
    end
end
if improved
    x, y = x_best, y_best
else
    α *= γ
end 
return x, α 
end
# Plotting for Simple 1:
# Contour for Simple 1:
xr = -2:0.1:2
yr = -2:0.1:2
contourf(xr, yr, simple1, levels=LinRange(-10,10, 21), colorbar = false, c = cgrad(:viridis, rev=true), legend = true, 
        xlims = (-2, 2), ylims = (-2, 2), xlabel = "x1", ylabel = "x2", aspectratio = :equal, clim = (-10,10))
contour!(xr, yr, simple1_constraints1, levels=[0], colorbar = false, c = cgrad(:viridis, rev=true), legend = true, 
        xlims = (-2, 2), ylims = (-2, 2), xlabel = "x1", ylabel = "x2", color = :red, aspectratio = :equal, clim = (-10,10))
contour!(xr, yr, simple1_constraints2, levels=[0], colorbar = false, c = cgrad(:viridis, rev=true), legend = true, 
        xlims = (-2, 2), ylims = (-2, 2), xlabel = "x1", ylabel = "x2", color = :orange, aspectratio = :equal, clim = (-10,10))
# Start Point 1:
#x_H1, f_H1 = hookjeeves(simple1, simple1_gradient, simple1_constraints, [-1.0,-1.0], 2000, .001, 0.5)
#plot!([x_H1[i][1] for i =1:length(x_H1)], [x_H1[i][2] for i =1:length(x_H1)], color = :black, label = "Path 1 [-1.0,-1.0]")
# Start Point 2:
# x_H2, f_H2 = hookjeeves(simple1, simple1_gradient, simple1_constraints, [0.5,0.5], 10000, .0001, 0.4)
# plot!([x_H2[i][1] for i =1:length(x_H2)], [x_H2[i][2] for i =1:length(x_H2)], color = :blue, label = "Path 2 [0.5,0.5]")
# # Start Point 3:
# x_H3, f_H3 = hookjeeves(simple1, simple1_gradient, simple1_constraints, [1.5, 1.5], 20000, .0001, 0.4 )
# plot!([x_H3[i][1] for i =1:length(x_H3)], [x_H3[i][2] for i =1:length(x_H3)], color = :red, label = "Path 3 [1.5, 1.5]")
# plot!(legend=:outerbottom, legendcolumns=3)
title!("Simple1 Contour")
savefig("Simple1_contour.png")

# # Plotting for Simple 2:
# Contour for Simple 2:
xr = -2:0.1:2
yr = -2:0.1:2
contourf(xr, yr, simple2, levels=LinRange(-10,10, 21), colorbar = false, c = cgrad(:viridis, rev=true), legend = true, 
        xlims = (-2, 2), ylims = (-2, 2), xlabel = "x1", ylabel = "x2", aspectratio = :equal, clim = (-10,10))
contour!(xr, yr, simple2_constraints1, levels=[0], colorbar = false, c = cgrad(:viridis, rev=true), legend = true, 
        xlims = (-2, 2), ylims = (-2, 2), xlabel = "x1", ylabel = "x2", color = :red, aspectratio = :equal, clim = (-10,10))
contour!(xr, yr, simple2_constraints2, levels=[0], colorbar = false, c = cgrad(:viridis, rev=true), legend = true, 
        xlims = (-2, 2), ylims = (-2, 2), xlabel = "x1", ylabel = "x2", color = :orange, aspectratio = :equal, clim = (-10,10))
# x_H1, f_H1 = hookjeeves(simple2, simple2_gradient, simple2_constraints, [-1.0,-1.0], 2000, .0001, 0.4)
x_H1, f_H1 = penalty_method(simple2, simple2_gradient, simple2_constraints, [-1.0,-1.0], 2000, 18.5, 0.25, .5, 200)
plot!([x_H1[i][1] for i =1:length(x_H1)], [x_H1[i][2] for i =1:length(x_H1)], color = :black, label = "Path 1 [-1.0,-1.0]")
# # Start Point 2:
x_H2, f_H2 = penalty_method(simple2, simple2_gradient, simple2_constraints, [0.5,0.5], 4000, 18.5, 0.25, .5, 200)
plot!([x_H2[i][1] for i =1:length(x_H2)], [x_H2[i][2] for i =1:length(x_H2)], color = :blue, label = "Path 2 [0.5,0.5]")
# # Start Point 3:
x_H3, f_H3 = penalty_method(simple2, simple2_gradient, simple2_constraints, [1.5, 1.5], 6000, 18.5, 0.25, .5, 200)
plot!([x_H3[i][1] for i =1:length(x_H3)], [x_H3[i][2] for i =1:length(x_H3)], color = :red, label = "Path 3 [1.5, 1.5]")
# plot!(legend=:outerbottom, legendcolumns=3)
title!("Simple2 Contour")
savefig("Simple2_contour.png")
